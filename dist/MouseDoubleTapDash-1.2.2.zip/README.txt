MOUSE: P.I. For Hire - Mouse Double Tap Dash
Version 1.2.2

WHAT IT DOES
Double-tap a movement key to dash in that direction.
- ZQSD on AZERTY / WASD on QWERTY (physical keys).
- The dash key is read from the game's runtime input binding; a profile fallback is used if needed.
  A rebind is followed within about 2 seconds.
- Toggle in Settings > Controls: "Double-tap dash" (Yes/No, localized).
- Timing is configurable in the BepInEx config file.

REQUIREMENTS
- BepInEx 5.4.23.5 x64 for MOUSE: P.I. For Hire, with the game-specific "unstripped" setup.
  On Nexus, use "Unstripped BepInEx for M.P.I.".
  Do NOT use a stock BepInEx package: this game ships stripped BCL assemblies and the preloader will fail.
- Single-player. No anti-cheat is involved.

INSTALL
1. Install the BepInEx unstripped package into the game root (the folder containing MOUSE.exe).
2. Launch the game once, then check that BepInEx/LogOutput.log exists.
3. Extract this archive into the game root. The result must be:
   <game>/BepInEx/plugins/MouseDoubleTapDash.dll
4. Launch the game.
5. Open Settings > Controls and set "Double-tap dash" to Yes.
   There is no keyboard shortcut.

CONFIG
File: BepInEx/config/com.cono.mousedoubletapdash.cfg

[General]
Enabled = true
DashKeyOverride =

[Timing]
DoubleTapWindowMs = 250
CooldownMs = 350

[Debug]
Verbose = false

DashKeyOverride: leave empty for automatic detection. If the wrong key is detected, set it to
the key name used by the game, for example LeftShift or LeftAlt. Keyboard keys only.

Change the values and restart the game. The in-game toggle is saved immediately.

UNINSTALL
Delete:
BepInEx/plugins/MouseDoubleTapDash.dll

NOTES
- Tested with the 14/10/2026 game build and BepInEx 5.4.23.5 (unstripped).
- The double tap is detected on the keyboard only. If Dash is bound to a mouse button or
  a gamepad, automatic detection falls back to a keyboard key.
- If the menu entry is missing after a game update, set Enabled in the config file and check
  BepInEx/LogOutput.log for "MouseDoubleTapDash".
- Linux / Steam Proton / Lutris: install the Windows BepInEx package in the game folder.
  No special launch options are required.
